lodgings = "lodgings"
boats = "boats"
slips = "slips"
loads = "loads"